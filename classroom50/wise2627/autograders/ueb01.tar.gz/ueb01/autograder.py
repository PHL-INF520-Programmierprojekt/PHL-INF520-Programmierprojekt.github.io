"""INF520-Autograder für Classroom 50 (schlanke Variante ohne Vorlagenkopie).

Classroom 50 startet dieses Skript im Checkout der Abgabe und erwartet danach
./result.json (Schema classroom50/result/v1). Das Skript
  1. holt den Startzustand des Repos: den Stand, den Classroom 50 beim Annehmen
     aus dem Starter-Repo kopiert und im Branch `feedback` eingefroren hat.
     Studierende können diesen Branch nicht ändern (Org-Ruleset
     classroom50-feedback-base-lock). Fehlt er, gilt der erste Commit von
     `main` (Force-Push dort verboten: classroom50-protect-submission-history),
  2. baut eine Bewertungskopie: Tests und Build aus dem Startzustand, aus der
     Abgabe nur die bearbeitbaren Dateien (Standard: src/main/** und .md-Dateien),
  3. startet einmal den Gradle-Wrapper und wertet die JUnit-Berichte aus:
     1 Punkt je vorgegebener Testmethode.

Optional daneben: inf520.json mit "bearbeitbar", "punkte", "zeitlimit_sekunden",
"testzeitlimit_sekunden". Ohne Datei gelten die Standardwerte.

Rückgabecode 0: Bewertung durchgeführt (auch bei 0 Punkten oder Compilerfehlern).
Rückgabecode ungleich 0: Infrastrukturfehler; Classroom 50 meldet dann status=error.
Nur Python-Standardbibliothek, Python 3.10 oder neuer.
"""
from __future__ import annotations

import datetime
import fnmatch
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path, PurePosixPath

HERE = Path(__file__).resolve().parent
MAX_MELDUNG = 600
MAX_LOG = 4000
# Antwortdateien dürfen laut Tests im Hauptverzeichnis oder unter src/ liegen.
STANDARD_BEARBEITBAR = ['src/main/**', '*.md', 'src/*.md']
STARTZUSTAND_REFS = ['refs/remotes/origin/feedback', 'refs/heads/feedback']
HAUPTBRANCH_REFS = ['refs/remotes/origin/main', 'refs/heads/main']


class Infrastrukturfehler(RuntimeError):
    """Die Bewertung konnte nicht durchgeführt werden; kein Fehler der Abgabe."""


def lade_konfiguration(paket: Path = HERE) -> dict:
    pfad = paket / 'inf520.json'
    data = json.loads(pfad.read_text(encoding='utf-8')) if pfad.is_file() else {}
    bearbeitbar = data.setdefault('bearbeitbar', list(STANDARD_BEARBEITBAR))
    if not isinstance(bearbeitbar, list) or not bearbeitbar or not all(isinstance(m, str) for m in bearbeitbar):
        raise Infrastrukturfehler('inf520.json: "bearbeitbar" muss eine nichtleere Liste von Mustern sein.')
    punkte = data.get('punkte', {})
    if not isinstance(punkte, dict) or not all(isinstance(v, int) and v >= 0 for v in punkte.values()):
        raise Infrastrukturfehler('inf520.json: "punkte" muss Testnamen auf ganze Zahlen >= 0 abbilden.')
    data.setdefault('standardpunkte', 1)
    data.setdefault('zeitlimit_sekunden', 600)
    # Eigene Tests der Studierenden prüfen Meta-Tests mit statischen Mocks; die gelten nur im
    # erzeugenden Thread, deshalb dort kein Zeitlimit je Test (das liefe in einem eigenen Thread).
    data.setdefault('testzeitlimit_sekunden', 0 if any(m.startswith('src/test/') for m in bearbeitbar) else 30)
    return data


def git(abgabe: Path, *argumente: str) -> subprocess.CompletedProcess:
    return subprocess.run(['git', '-C', str(abgabe), *argumente], capture_output=True, check=False)


def startzustand_commit(abgabe: Path) -> str:
    """Commit des eingefrorenen Startzustands; Studierende können ihn nicht verändern."""
    for ref in STARTZUSTAND_REFS:
        lauf = git(abgabe, 'rev-parse', '--verify', '--quiet', ref + '^{commit}')
        if lauf.returncode == 0:
            return lauf.stdout.decode().strip()
    for ref in HAUPTBRANCH_REFS:
        lauf = git(abgabe, 'rev-list', '--max-parents=0', ref)
        wurzeln = lauf.stdout.decode().split() if lauf.returncode == 0 else []
        if len(wurzeln) == 1:
            return wurzeln[0]
    raise Infrastrukturfehler('Startzustand nicht gefunden: weder Branch "feedback" noch ein eindeutiger '
                              'erster Commit auf "main".')


def entpacke_startzustand(abgabe: Path, commit: str, ziel: Path) -> None:
    lauf = git(abgabe, 'archive', '--format=tar', commit)
    if lauf.returncode != 0:
        raise Infrastrukturfehler('git archive fehlgeschlagen: ' + lauf.stderr.decode(errors='replace'))
    with tarfile.open(fileobj=io.BytesIO(lauf.stdout)) as archiv:
        if sys.version_info >= (3, 12):
            archiv.extractall(ziel, filter='data')
            return
        for eintrag in archiv.getmembers():
            name = PurePosixPath(eintrag.name)
            if eintrag.issym() or eintrag.islnk() or name.is_absolute() or '..' in name.parts:
                continue
            archiv.extract(eintrag, ziel)


# Zwischen @Test und der Methode dürfen weitere Annotationen und Kommentare stehen.
_ZWISCHEN = r'(?:\s+|//[^\n]*|/\*.*?\*/|@\w+(?:\([^)]*\))?)*'
TEST_METHODE = re.compile(r'@Test\b' + _ZWISCHEN + r'(?:public\s+|protected\s+|private\s+)?void\s+(\w+)\s*\(', re.S)
TEST_ANNOTATION = re.compile(r'^\s*@Test\b', re.M)


def vorgegebene_tests(vorlage: Path, bearbeitbar: list[str]) -> dict[str, int]:
    """Je vorgegebener Testmethode 1 Punkt. Testklassen, die Studierende selbst schreiben
    dürfen, und die technische Selbstprüfung TestEnvironmentTest zählen nicht."""
    punkte = {}
    test_root = vorlage / 'src' / 'test' / 'java'
    for datei in sorted(test_root.rglob('*.java')) if test_root.is_dir() else []:
        relativ = datei.relative_to(vorlage).as_posix()
        if ist_bearbeitbar(relativ, bearbeitbar) or datei.stem == 'TestEnvironmentTest':
            continue
        text = datei.read_text(encoding='utf-8')
        methoden = TEST_METHODE.findall(text)
        # Lieber abbrechen als einen Test still mit 0 von 0 Punkten zu werten.
        if len(methoden) != len(TEST_ANNOTATION.findall(text)):
            raise Infrastrukturfehler(f'{relativ}: Nicht alle @Test-Methoden erkannt; Punkte in inf520.json angeben.')
        for methode in methoden:
            punkte[f'{datei.stem}.{methode}'] = 1
    return punkte


def ist_bearbeitbar(relativ: str, muster: list[str]) -> bool:
    """Glob-Muster mit '/' als Trenner; '**' passt auf beliebig viele Ordner."""
    for m in muster:
        if m.endswith('/**') and (relativ == m[:-3] or relativ.startswith(m[:-2])):
            return True
        if fnmatch.fnmatchcase(relativ, m) and ('/' in m or '/' not in relativ):
            return True
    return False


def regulaere_dateien(root: Path) -> dict[str, Path]:
    """Alle regulären Dateien unterhalb von root; Verknüpfungen und .git werden übersprungen."""
    result: dict[str, Path] = {}
    root = root.resolve()
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        current = Path(dirpath)
        dirnames[:] = [d for d in dirnames if d not in {'.git', '.gradle', 'build'}
                       and not (current / d).is_symlink()]
        for name in filenames:
            path = current / name
            if path.is_symlink() or not path.is_file():
                continue
            relativ = path.relative_to(root).as_posix()
            if '..' in PurePosixPath(relativ).parts:
                continue
            result[relativ] = path
    return result


def bewertungskopie(vorlage: Path, abgabe: Path, ziel: Path, muster: list[str]) -> list[str]:
    """Vorlage ohne bearbeitbare Dateien plus bearbeitbare Dateien der Abgabe.

    Gibt die Liste der aus der Abgabe übernommenen Dateien zurück.
    """
    uebernommen = []
    for relativ, quelle in sorted(regulaere_dateien(vorlage).items()):
        if not ist_bearbeitbar(relativ, muster):
            ziel_datei = ziel / relativ
            ziel_datei.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(quelle, ziel_datei)
    for relativ, quelle in sorted(regulaere_dateien(abgabe).items()):
        if ist_bearbeitbar(relativ, muster):
            ziel_datei = ziel / relativ
            ziel_datei.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(quelle, ziel_datei)
            uebernommen.append(relativ)
    return uebernommen


def gradle_befehl(projekt: Path) -> list[str]:
    if os.name == 'nt':
        return [str(projekt / 'gradlew.bat')]
    return ['bash', str(projekt / 'gradlew')]


def beende_prozessbaum(prozess: subprocess.Popen) -> None:
    """Gradle startet eigene JVMs; bei Zeitüberschreitung den ganzen Baum beenden."""
    if os.name == 'nt':
        subprocess.run(['taskkill', '/T', '/F', '/PID', str(prozess.pid)],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
    else:
        import signal
        try:
            os.killpg(prozess.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    prozess.wait()


def init_skript(ziel: Path, testzeitlimit: int) -> Path:
    """Zeitlimit je Test: Eine Endlosschleife kostet nur den betroffenen Test.

    SEPARATE_THREAD beendet den Test auch, wenn die Schleife Unterbrechungen ignoriert.
    Nicht geeignet für Meta-Tests, die eigene Tests der Studierenden in einem
    verschachtelten JUnit-Lauf mit statischen Mocks prüfen (ÜB 0b, ÜB 10):
    Statische Mocks gelten nur im erzeugenden Thread. Dort testzeitlimit_sekunden = 0.
    """
    skript = ziel / 'inf520-bewertung.init.gradle'
    skript.write_text(
        'allprojects {\n'
        '    tasks.withType(Test).configureEach {\n'
        f"        systemProperty 'junit.jupiter.execution.timeout.default', '{testzeitlimit} s'\n"
        "        systemProperty 'junit.jupiter.execution.timeout.thread.mode.default', 'SEPARATE_THREAD'\n"
        '    }\n'
        '}\n', encoding='utf-8')
    return skript


def starte_gradle(projekt: Path, zeitlimit: int, testzeitlimit: int = 30) -> tuple[int | None, str]:
    """Gibt (Rückgabecode oder None bei Zeitüberschreitung, Ausgabe) zurück.

    Die Ausgabe geht in eine Datei statt in Pipes: Nachfolgeprozesse von Gradle
    könnten Pipes sonst auch nach einem Abbruch offen halten.
    """
    befehl = gradle_befehl(projekt) + ['test', '--continue', '--no-daemon', '--console=plain']
    if testzeitlimit > 0:
        befehl += ['--init-script', str(init_skript(projekt.parent, testzeitlimit))]
    protokoll = projekt.parent / 'gradle-ausgabe.txt'
    with protokoll.open('wb') as ausgabe:
        try:
            prozess = subprocess.Popen(befehl, cwd=projekt, stdin=subprocess.DEVNULL, stdout=ausgabe,
                                       stderr=subprocess.STDOUT, start_new_session=(os.name != 'nt'))
        except OSError as fehler:
            raise Infrastrukturfehler(f'Gradle konnte nicht gestartet werden: {fehler}') from fehler
        try:
            code: int | None = prozess.wait(timeout=zeitlimit)
        except subprocess.TimeoutExpired:
            beende_prozessbaum(prozess)
            code = None
    return code, protokoll.read_text(encoding='utf-8', errors='replace')


def lese_junit(ergebnisordner: Path) -> dict[str, tuple[bool, str]]:
    """Testname 'Klasse.methode' -> (bestanden, Meldung)."""
    ergebnisse: dict[str, tuple[bool, str]] = {}
    for xml in sorted(ergebnisordner.glob('*.xml')):
        wurzel = ET.parse(xml).getroot()
        for fall in wurzel.iter('testcase'):
            klasse = (fall.get('classname') or '').rsplit('.', 1)[-1]
            name = f"{klasse}.{fall.get('name', '').removesuffix('()')}"
            problem = next((fall.find(tag) for tag in ('failure', 'error') if fall.find(tag) is not None), None)
            if problem is not None:
                meldung = (problem.get('message') or problem.get('type') or 'fehlgeschlagen').strip()
                ergebnisse[name] = (False, meldung[:MAX_MELDUNG])
            elif fall.find('skipped') is not None:
                ergebnisse[name] = (False, 'übersprungen')
            else:
                ergebnisse[name] = (True, '')
    return ergebnisse


def compilerfehler(ausgabe: str) -> bool:
    return any(marke in ausgabe for marke in (
        'compileJava FAILED', 'compileTestJava FAILED', 'Compilation failed'))


def bewerte(ergebnisse: dict[str, tuple[bool, str]], konfiguration: dict) -> list[dict]:
    punkte: dict = konfiguration.get('punkte', {})
    standard = konfiguration['standardpunkte']
    # Konfigurierte Tests sind verbindlich: fehlt ein Ergebnis, zählt der Test als nicht bestanden.
    namen = list(punkte) + sorted(n for n in ergebnisse if n not in punkte) if punkte else sorted(ergebnisse)
    tests = []
    for name in namen:
        bestanden, meldung = ergebnisse.get(name, (False, 'Test wurde nicht ausgeführt.'))
        maximal = punkte.get(name, 0 if punkte else standard)
        eintrag = {'test-name': name, 'passed': bestanden, 'score': maximal if bestanden else 0,
                   'max-score': maximal}
        if meldung:
            eintrag['message'] = meldung
        tests.append(eintrag)
    return tests


def ergebnis(tests: list[dict]) -> dict:
    jetzt = datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    umgebung = os.environ
    commit = umgebung.get('COMMIT_URL', '')
    return {
        'schema': 'classroom50/result/v1',
        'classroom': umgebung.get('CLASSROOM', ''),
        'assignment': umgebung.get('ASSIGNMENT', ''),
        'submission': umgebung.get('SUBMISSION_TAG', ''),
        'commit': commit,
        'release': umgebung.get('RELEASE_URL', ''),
        'review': umgebung.get('REVIEW_URL') or commit,
        'datetime': jetzt,
        'graded_at': jetzt,
        # result.json-Schema: Tests ohne Zusatzfelder; Meldungen stehen in release-body.md.
        'score': sum(t['score'] for t in tests),
        'max-score': sum(t['max-score'] for t in tests),
        'tests': [{k: t[k] for k in ('test-name', 'passed', 'score', 'max-score')} for t in tests],
    }


def rueckmeldung(tests: list[dict], hinweis: str = '', log: str = '') -> str:
    erreicht = sum(t['score'] for t in tests)
    maximal = sum(t['max-score'] for t in tests)
    zeilen = ['## Automatische Rückmeldung INF520', '', f'**Punkte: {erreicht} von {maximal}**', '']
    if hinweis:
        zeilen += [hinweis, '']
    offen = [t for t in tests if not t['passed']]
    if offen:
        zeilen += ['### Noch nicht bestanden', '']
        for t in offen:
            meldung = ' '.join(t.get('message', '').split())
            zeilen.append(f"- `{t['test-name']}`" + (f': {meldung}' if meldung else ''))
        zeilen.append('')
    else:
        zeilen += ['Alle automatischen Tests bestanden.', '']
    if log:
        zeilen += ['<details><summary>Auszug aus der Gradle-Ausgabe</summary>', '', '```text', log, '```',
                   '', '</details>', '']
    zeilen.append('Die automatischen Tests sind eine Rückmeldung. Die abschließende Bewertung erfolgt durch '
                  'die Lehrenden.')
    return '\n'.join(zeilen) + '\n'


def relevante_ausgabe(ausgabe: str) -> str:
    zeilen = [z for z in ausgabe.splitlines()
              if 'error:' in z or 'FAILED' in z or 'What went wrong' in z or z.startswith('> ')]
    return '\n'.join(zeilen)[-MAX_LOG:] or ausgabe[-MAX_LOG:]


def bewertung_ausfuehren(abgabe: Path, paket: Path = HERE) -> tuple[dict, str]:
    konfiguration = lade_konfiguration(paket)
    # Nach einem Abbruch können unter Windows gesperrte Gradle-Dateien zurückbleiben.
    with tempfile.TemporaryDirectory(prefix='inf520-bewertung-', ignore_cleanup_errors=True) as tmp:
        vorlage = Path(tmp) / 'startzustand'
        vorlage.mkdir()
        entpacke_startzustand(abgabe, startzustand_commit(abgabe), vorlage)
        if not (vorlage / 'build.gradle.kts').is_file():
            raise Infrastrukturfehler('Im Startzustand fehlt build.gradle.kts.')
        if not konfiguration.get('punkte'):
            konfiguration['punkte'] = vorgegebene_tests(vorlage, konfiguration['bearbeitbar'])
        if not konfiguration['punkte']:
            raise Infrastrukturfehler('Im Startzustand wurden keine vorgegebenen Tests gefunden.')
        projekt = Path(tmp) / 'projekt'
        projekt.mkdir()
        bewertungskopie(vorlage, abgabe, projekt, konfiguration['bearbeitbar'])
        code, ausgabe = starte_gradle(projekt, int(konfiguration['zeitlimit_sekunden']),
                                      int(konfiguration['testzeitlimit_sekunden']))
        ergebnisse = lese_junit(projekt / 'build' / 'test-results' / 'test')

    if code is None:
        tests = bewerte(ergebnisse, konfiguration)
        hinweis = ('Der Testlauf wurde wegen Zeitüberschreitung abgebrochen. Prüfen Sie Endlosschleifen '
                   'und Eingaben über die Konsole.')
        return ergebnis(tests), rueckmeldung(tests, hinweis, relevante_ausgabe(ausgabe))
    if not ergebnisse:
        if compilerfehler(ausgabe):
            tests = bewerte({}, konfiguration)
            hinweis = ('Das Projekt kompiliert nicht; deshalb konnte kein Test laufen. '
                       'Beheben Sie zuerst die Compilerfehler.')
            return ergebnis(tests), rueckmeldung(tests, hinweis, relevante_ausgabe(ausgabe))
        raise Infrastrukturfehler('Gradle lieferte keine Testergebnisse:\n' + relevante_ausgabe(ausgabe))
    tests = bewerte(ergebnisse, konfiguration)
    return ergebnis(tests), rueckmeldung(tests)


def main() -> int:
    try:
        result, text = bewertung_ausfuehren(Path.cwd())
    except (Infrastrukturfehler, OSError, ValueError, ET.ParseError, tarfile.TarError) as fehler:
        print(f'::error::INF520-Autograder: {fehler}', file=sys.stderr)
        return 1
    Path('result.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    Path('release-body.md').write_text(text, encoding='utf-8')
    print(f"INF520: {result['score']} von {result['max-score']} Punkten")
    return 0


if __name__ == '__main__':
    sys.exit(main())
